'''
hello.py
Name: Wengel Gemu
Collaborators: None
Date: August 28, 2019
Description: Prints "Hello, Wengel", within a box of stars
'''



# Welcome to your first Python program!
# Let's print to your console

print("******************")
print("*                *")
print("* Hello, Wengel! *")
print("*                *")
print("******************")

# In Atom, right-click the filename -> Run 'hello'
# You should see "Hello, World!" in your shell.

# Write a program that will print "Hello, <your name>!!!"
# in a box like the one below

# **************************
# *                        *
# * Hello, Harry Potter!!! *
# *                        *
# **************************
