# CMSI185-ps0

In this first assignment, you will install Python 3, Atom (or use your favorite text editor instead), learn to use GitHub for submitting code, and animate a plane landing!

## What to submit:

1) ```hello.py```

2) ```ufo.py```